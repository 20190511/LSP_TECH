#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>


#define LINE_MAX 2048


static void ssu_alarm(int signo);

int main(void)
{
	char buf[LINE_MAX];
	int n;

	if (signal(SIGALRM, ssu_alarm) == SIG_ERR) {
		fprintf(stderr, "SIGALRM error\n");
		exit(1);
	}

	alarm(10); 
	//10초 안에 stdin을 입력하지 않으면 ssu_alarm()이 call 된다.
	if ((n=read(STDIN_FILENO, buf, LINE_MAX)) < 0) {
		fprintf(stderr, "read() error\n");
		exit(1);
	}

	alarm(0); //alarm 을 취소함
	write(STDOUT_FILENO, buf, n); //stdin으로부터 입력받은 buf를 출력함
	exit(0);
}

static void ssu_alarm(int signo) {
	printf("ssu_alarm() called\n");
}

