#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

int main(void)
{
	sigset_t set;

	sigemptyset(&set);
	sigaddset(&set, SIGINT);
	//SIGINT가 set에 들어가 있는지 검사 --> SIGSET만 add 되어있기 때문에있을 것
	switch (sigismember(&set, SIGINT))
	{
		case 1:
			printf("SIGINT is included. \n");
			break;
		case 0:
			printf("SIGINT is not included. \n");
			break;
		default:
			printf("failed to call sigismember() \n");
	}
	// SIGSYS가 set에 들어가 있는지 검사
	switch (sigismember(&set, SIGSYS)) 
	{
		case 1:
			printf("SIGSYS is included. \n");
			break;
		case 0:
			printf("SIGSYS is not included. \n");
			break;
		default:
			printf("failed to call sigismember() \n");
	}

	exit(0);
}
		


