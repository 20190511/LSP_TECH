#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

void ssu_signal_handler(int signo);

int count=0;

int main(void)
{
	signal(SIGALRM, ssu_signal_handler); //SIGALRM 을 ssu_handler로 설정
	alarm(1);

	while(1);

	exit(0);
}


void ssu_signal_handler(int signo)
{
	printf("alarm %d\n", count++);
	alarm(1); //알람을 계속 호출하여 재귀호출 형태를 띄게함
}


